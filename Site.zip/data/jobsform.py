from flask_wtf import FlaskForm
from wtforms import TextAreaField, BooleanField, SubmitField


class JobsForm(FlaskForm):
    job_title = TextAreaField("Job Title")
    team_leader_id = TextAreaField("Team Leader id")
    work_size = TextAreaField("Work Size")
    collaborators = TextAreaField("Collaborators")
    is_finished = BooleanField('Is job finished?')
    submit = SubmitField('Добавить')
